import wikipedia

wikipedia.search('test')
